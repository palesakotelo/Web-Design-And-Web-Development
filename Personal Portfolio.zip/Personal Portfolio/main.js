const menuTitems = document.querySelectorAll('nav ul li a');
const sections = document.querySelectorAll('section');

const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.7
};

const observer = new IntersectionObserver ((e) => {
    e.forEach(entry => {
        const menuTitem = 
        document.querySelector ('nav ul li a[href="${entry.target,id}"]');
        menuTitem.classList.toggle('active',entry.isIntersecting);
    });
}, observerOptions);

sections.forEach(section => {
    observer.observe(section);
});

menuTitems.forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();

        menuTitems.forEach(item => item.classList.remove('active'));
        item.classList.add('active');

        const targetSection = document.querySelector(item.getAttribute('href'));
        const targetOffset = targetSection.offsetTop;

        scrollSection(targetOffset);
    });
});

const scrollSection = (targetOffset) => {
    const initialOffset = window.scrollY;
    const distance = targetOffset- initialOffset;
    const duration = 500;
    const startTime = performance.now();

    const animateScroll = (currentTime) => {
        const elapsedTime = currentTime- startTime;
        const progress = Math.min(elapsedTime/ duration,1);
        const easedProgress = ease(progress);
        const newPosition = initialOffset + distance * easedProgress;

        window.scrollTo(0, newPosition);

        if(elapsedTime < duration){
            requestAnimationFrame(animateScroll);
        }
    }

    requestAnimationFrame(animateScroll);
}

 const ease = (t) => {
    return t;
 }
   
